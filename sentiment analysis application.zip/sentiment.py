import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
import joblib
import os

# Load the dataset
df = pd.read_csv("C:/Users/valli adabala/Downloads/Tweets.csv")

# Drop rows with missing values
df.dropna(subset=['text'], inplace=True)

# Drop unnecessary columns
df.drop(['selected_text', 'textID'], axis=1, inplace=True)

# Check if model files exist
model_exists = os.path.isfile("logistic_regression_model.pkl")
vectorizer_exists = os.path.isfile("tfidf_vectorizer.pkl")

if model_exists and vectorizer_exists:
    # Load the saved model and vectorizer
    LR = joblib.load("logistic_regression_model.pkl")
    vectorizer = joblib.load("tfidf_vectorizer.pkl")
else:
    # Initialize TfidfVectorizer and Logistic Regression model
    vectorizer = TfidfVectorizer()
    X = vectorizer.fit_transform(df['text']).toarray()
    y = df['sentiment']

    LR_model = LogisticRegression()
    LR = LR_model.fit(X, y)

    # Save the trained model to disk
    joblib.dump(LR, "logistic_regression_model.pkl")
    joblib.dump(vectorizer, "tfidf_vectorizer.pkl")

# Create Tkinter GUI window
root = tk.Tk()
root.title("Sentiment Analysis Predictor (Logistic Regression)")

# Define function for sentiment prediction using Logistic Regression
def predict_sentiment_lr(text):
    text_features = vectorizer.transform([text]).toarray()
    lr_prediction = LR.predict(text_features)[0]
    return lr_prediction

# Define function to handle button click event
def predict():
    text = text_entry.get("1.0",'end-1c')
    if text.strip() == "":
        messagebox.showwarning("Warning", "Please enter some text for prediction.")
        return
    lr_prediction = predict_sentiment_lr(text)
    lr_label.config(text="LR Prediction: " + lr_prediction)

# Add text entry widget
text_label = ttk.Label(root, text="Enter text:")
text_label.grid(row=0, column=0, padx=10, pady=10, sticky="w")
text_entry = tk.Text(root, height=10, width=50)
text_entry.grid(row=0, column=1, padx=10, pady=10, sticky="w")

# Add prediction button
predict_button = ttk.Button(root, text="Predict", command=predict)
predict_button.grid(row=1, column=1, padx=10, pady=10, sticky="e")

# Add label to display prediction
lr_label = ttk.Label(root, text="LR Prediction: ")
lr_label.grid(row=2, column=1, padx=10, pady=10, sticky="w")

# Run the Tkinter event loop
root.mainloop()